package org.in5bv.pablocalitoruddycuyan.system;

import java.io.IOException;
import javafx.scene.image.Image;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import org.in5bv.pablocalitoruddycuyan.controllers.AlumnosController;
import org.in5bv.pablocalitoruddycuyan.controllers.CarrerasTecnicasController;
import org.in5bv.pablocalitoruddycuyan.controllers.MenuPrincipalController;
import org.in5bv.pablocalitoruddycuyan.controllers.SalonesController;

/**
 *
 * @author HOME
 */
public class Principal extends Application {

    private Stage escenarioPrincipal;
    private final String PAQUETE_IMAGE = "org/in5bv/pablocalitoruddycuyan/resources/images/";
    private final String PAQUETE_VIEW = "../views/";

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        this.escenarioPrincipal = primaryStage;
        this.escenarioPrincipal.setTitle("Control Academico Kinal");
        this.escenarioPrincipal.getIcons().add(new Image(PAQUETE_IMAGE + "K (1).png"));
        this.escenarioPrincipal.setResizable(false);
        this.escenarioPrincipal.centerOnScreen();
        
        mostrarScenaPrincipal();

        
    }

    public void mostrarScenaPrincipal() {
        try {
            MenuPrincipalController menuController = (MenuPrincipalController) cambiarEscena("MenuPrincipalView.fxml", 900, 590);
            menuController.setEcenarioPrincipal(this);
        } catch (Exception ex) {
            System.err.println("\n Se a producido un error al mostrar la vista Menu Principal");
            ex.printStackTrace();
        }
    }

    public void mostrarScenaAlumnos() {
        try {
            AlumnosController alumnosController = (AlumnosController) cambiarEscena("AlumnosView.fxml", 900, 590);
            alumnosController.setEscenarioPrincipal(this);
        } catch (Exception ex) {
            System.err.println("\n Se a producido un error al mostrar la vista Alumnos");
            ex.printStackTrace();
        }
    }
    
    public void mostrarScenaSalones() {
        try {
            SalonesController salonesController = (SalonesController) cambiarEscena("SalonesViews.fxml", 900, 590);
            salonesController.setEcenarioPrincipal(this);
        } catch (Exception ex){
            System.err.println("\n Se a producido un error al mostrar la vista Salones");
            ex.printStackTrace();
        }
    }
    
    public void mostrarScenaCarrerasTecnicas() {
        try {
            CarrerasTecnicasController carrerasTecnicasController = (CarrerasTecnicasController) cambiarEscena("CarrerasTecnicasView.fxml", 900, 590);
            carrerasTecnicasController.setEcenarioPrincipal(this);
        } catch (Exception ex) {
            System.err.println("\n Se a producido un error al mostrar la vista Carreras Tecnicas");
            ex.printStackTrace();
        }
    }

    /*public Initializable cambiarEscena(String vistaFxml, int ancho, int alto) throws IOException {
        Initializable resultado = null;

        FXMLLoader cargadorFXML = new FXMLLoader();

        cargadorFXML.setBuilderFactory(new JavaFXBuilderFactory());

        cargadorFXML.setLocation(Principal.class.getResource(PAQUETE_VIEW + vistaFxml));
    
        InputStream archivo = Principal.class.getResourceAsStream(PAQUETE_VIEW + vistaFxml);

        AnchorPane root = cargadorFXML.load(archivo);

        Scene nuevaEscena = new Scene(root);

        this.escenarioPrincipal.setScene(nuevaEscena);

        this.escenarioPrincipal.show();

        resultado = (Initializable) cargadorFXML.getController();

        return resultado;
    }
     */
    public Initializable cambiarEscena(String vistaFxml, int ancho, int alto) throws IOException {
        System.out.println("Cambiando de escena: " + PAQUETE_VIEW + vistaFxml);
        FXMLLoader cargadorFXML = new FXMLLoader(getClass().getResource(PAQUETE_VIEW + vistaFxml));
        Scene scene = new Scene((AnchorPane) cargadorFXML.load(), ancho, alto);
        this.escenarioPrincipal.setScene(scene);
        this.escenarioPrincipal.sizeToScene();
        this.escenarioPrincipal.show();
        return (Initializable) cargadorFXML.getController();
    }

}
