

package org.in5bv.pablocalitoruddycuyan.models;

/**
 *
 * @author Pablo Andrés Calito del Cid
 * @date 26 abr 2022
 * @time 14:41:27
 *
 * Carne: 2021253
 * Codigo Tecnico: IN5BV
 * Carrera: Informatica
 * Grupo: 2
 * Jornada: Vespertina
 */

public class Salones {
    private String codigoSalones;
    private String descripcion;
    private int capacidadMaxima;
    private String edificio;
    private int nivel;

    public Salones() {
    }

    public Salones(String codigoSalones) {
        this.codigoSalones = codigoSalones;
    }

    public Salones(String codigoSalones, String descripcion, int capacidadMaxima) {
        this.codigoSalones = codigoSalones;
        this.descripcion = descripcion;
        this.capacidadMaxima = capacidadMaxima;
    }

    public Salones(String descripcion, int capacidadMaxima, String edificio, int nivel) {
        this.descripcion = descripcion;
        this.capacidadMaxima = capacidadMaxima;
        this.edificio = edificio;
        this.nivel = nivel;
    }

    public Salones(String codigoSalones, String descripcion, int capacidadMaxima, String edificio, int nivel) {
        this.codigoSalones = codigoSalones;
        this.descripcion = descripcion;
        this.edificio = edificio;
        this.nivel = nivel;

    }

    public String getCodigoSalones() {
        return codigoSalones;
    }

    public void setCodigoSalones(String codigoSalones) {
        this.codigoSalones = codigoSalones;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getCapacidadMaxima() {
        return capacidadMaxima;
    }

    public void setCapacidadMaxima(int capacidadMaxima) {
        this.capacidadMaxima = capacidadMaxima;
    }

    public String getEdificio() {
        return edificio;
    }

    public void setEdificio(String edificio) {
        this.edificio = edificio;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    @Override
    public String toString() {
        return "Salones{" + "codigoSalones=" + codigoSalones + ", descripcion=" + descripcion + ", capacidadMaxima=" + capacidadMaxima + ", edificio=" + edificio + ", nivel=" + nivel + '}';
    }
    
    
}
