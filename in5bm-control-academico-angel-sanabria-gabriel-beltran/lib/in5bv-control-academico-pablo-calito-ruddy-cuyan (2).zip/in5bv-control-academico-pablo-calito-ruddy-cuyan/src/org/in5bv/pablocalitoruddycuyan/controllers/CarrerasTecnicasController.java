package org.in5bv.pablocalitoruddycuyan.controllers;

import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import org.in5bv.pablocalitoruddycuyan.models.Alumnos;
import org.in5bv.pablocalitoruddycuyan.models.CarrerasTecnicas;
import org.in5bv.pablocalitoruddycuyan.system.Principal;
import org.pablocalitoruddycuyan.db.Conexion;

/**
 *
 * @author Pablo Andrés Calito del Cid
 * @date 29 abr 2022
 * @time 11:56:39
 *
 * Carne: 2021253 Codigo Tecnico: IN5BV Carrera: Informatica Grupo: 2 Jornada:
 * Vespertina
 */
public class CarrerasTecnicasController implements Initializable {

    private Principal escenarioPrincipal;

    
    
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
//getCarreras_tecnicas();
        cargarDatos();
    }

    public void cargarDatos() {
        tblCarrerasTecnicas.setItems(getCarrerasTecnicas());
        colCodigoTecnico.setCellValueFactory(new PropertyValueFactory<Alumnos, String>("codigoTecnico"));
        colCarrera.setCellValueFactory(new PropertyValueFactory<Alumnos, String>("carrera"));
        colGrado.setCellValueFactory(new PropertyValueFactory<Alumnos, String>("grado"));
        colSeccion.setCellValueFactory(new PropertyValueFactory<Alumnos, String>("seccion"));
        colJornada.setCellValueFactory(new PropertyValueFactory<Alumnos, String>("jornada"));
    }

    public ObservableList<CarrerasTecnicas> getCarrerasTecnicas() {
        ArrayList<CarrerasTecnicas> lista = new ArrayList<>();
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {

            pstmt = Conexion.getInstance().getConexion().prepareCall("CALL sp_carreras_tecnicas_read()");
            rs = pstmt.executeQuery();
            while (rs.next()) {
                CarrerasTecnicas carreras = new CarrerasTecnicas();
                carreras.setCodigoTecnico(rs.getString(1));
                carreras.setCarrera(rs.getString(2));
                carreras.setGrado(rs.getString(3));
                carreras.setSeccion(rs.getString(4));
                carreras.setJornada(rs.getString(5));

                lista.add(carreras);
                System.out.println(carreras.toString());

            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {

            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return FXCollections.observableArrayList(lista);
    }

    public Principal getEcenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEcenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }

// TEXTOS
    @FXML
    private TextField txtCodigoTecnico;
    @FXML
    private TextField txtCarrera;
    @FXML
    private TextField txtGrado;
    @FXML
    private TextField txtSeccion;
    @FXML
    private TextField txtJornada;

    // BOTONES
    @FXML
    private Button btnNuevo;
    @FXML
    private Button btnModificar;
    @FXML
    private Button btnEliminar;
    @FXML
    private Button btnReporte;

    // TABLAS 
    @FXML
    private TableView tblCarrerasTecnicas;
    @FXML
    private TableColumn colCodigoTecnico;
    @FXML
    private TableColumn colCarrera;
    @FXML
    private TableColumn colGrado;
    @FXML
    private TableColumn colSeccion;
    @FXML
    private TableColumn colJornada;

    private void habilitarCampos() {
        txtCodigoTecnico.setEditable(true);
        txtCarrera.setEditable(true);
        txtGrado.setEditable(true);
        txtSeccion.setEditable(true);
        txtJornada.setEditable(true);

        txtCodigoTecnico.setDisable(false);
        txtCarrera.setDisable(false);
        txtGrado.setDisable(false);
        txtSeccion.setDisable(false);
        txtJornada.setDisable(false);
    }

    private void limpiarCampos() {
        txtCodigoTecnico.setText("");
        txtCarrera.setText("");
        txtGrado.setText("");
        txtSeccion.setText("");
        txtJornada.setText("");
    }

    @FXML
    private void clicNuevo() {
        habilitarCampos();
        limpiarCampos();
    }

    @FXML
    private void clicModificar() {
        habilitarCampos();
    }

    @FXML
    public void clicRegresar() {
        escenarioPrincipal.mostrarScenaPrincipal();
    }

    @FXML
    private void clicReporte() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setTitle("AVISO");
        alert.setContentText("Esta opcion esta disponible solo para la version PRO !");

        Stage stageAlert = (Stage) alert.getDialogPane().getScene().getWindow();
        stageAlert.getIcons().add(new Image("org/in5bv/pablocalito/resources/images/K (1).png"));
        alert.showAndWait();
    }
}
