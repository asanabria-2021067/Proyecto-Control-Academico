package org.in5bv.pablocalitoruddycuyan.controllers;

/**
 *
 * @author Pablo Andrés Calito del Cid
 * @date 28 abr 2022
 * @time 22:22:58
 *
 * Carne: 2021253 Codigo Tecnico: IN5BV Carrera: Informatica Grupo: 2 Jornada:
 * Vespertina
 */
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import org.in5bv.pablocalitoruddycuyan.models.Salones;
import org.in5bv.pablocalitoruddycuyan.system.Principal;
import org.pablocalitoruddycuyan.db.Conexion;

public class SalonesController implements Initializable {

    private final String PAQUETE_IMAGE = "org/in5bv/pablocalitoruddycuyan/resources/images/";

    private enum Operacion {
        NINGUNO, GUARDAR, ACTUALIZAR
    }
    private Operacion operacion = Operacion.NINGUNO;
    private Principal escenarioPrincipal;
    private ObservableList<Salones> listaSalones;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
//getSalones();
        cargarDatos();
    }

    public void cargarDatos() {
        tblSalones.setItems(getSalones());
        colCodigoSalon.setCellValueFactory(new PropertyValueFactory<Salones, String>("codigoSalones"));
        colDescripcion.setCellValueFactory(new PropertyValueFactory<Salones, String>("descripcion"));
        colCapacidadMaxima.setCellValueFactory(new PropertyValueFactory<Salones, String>("capacidadMaxima"));
        colEdificio.setCellValueFactory(new PropertyValueFactory<Salones, String>("edificio"));
        colNivel.setCellValueFactory(new PropertyValueFactory<Salones, String>("nivel"));
    }

    public ObservableList getSalones() {
        ArrayList<Salones> lista = new ArrayList<>();
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("CALL sp_salones_read()");
            rs = pstmt.executeQuery();
            while (rs.next()) {
                Salones salones = new Salones();
                salones.setCodigoSalones(rs.getString(1));
                salones.setDescripcion(rs.getString(2));
                salones.setCapacidadMaxima(rs.getInt(3));
                salones.setEdificio(rs.getString(4));
                salones.setNivel(rs.getInt(5));

                lista.add(salones);

                System.out.println(salones.toString());
            }
            listaSalones = FXCollections.observableArrayList(lista);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {

            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return listaSalones;
    }
    
    private boolean eliminarSalon() {
        if (existeElementoSeleccionado()) {
            
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setHeaderText(null);
                alert.setTitle("CONFIRMACION");
                alert.setContentText("¿Estas seguro que deseas ELIMINAR este Salon?");

                Stage stageAlert = (Stage) alert.getDialogPane().getScene().getWindow();
                stageAlert.getIcons().add(new Image(PAQUETE_IMAGE + "K (1).png"));
                alert.showAndWait();
            
            Salones salon = (Salones) tblSalones.getSelectionModel().getSelectedItem();

            PreparedStatement pstmt = null;

            try {
                
                pstmt = Conexion.getInstance().getConexion().prepareCall("CALL sp_alumnos_delete(?)");
                pstmt.setString(1, salon.getCodigoSalones());
                System.out.println(pstmt);
                pstmt.execute();
                return true;
            } catch (SQLException e) {
                System.out.println("\nSe produjo un error cuando se intento eliminar el siguiente registro: " + salon.toString());
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public boolean existeElementoSeleccionado() {
        return (tblSalones.getSelectionModel().getSelectedItem() != null);
    }

    @FXML
    public void seleccionarElemento() {

        if (existeElementoSeleccionado()) {
            txtCodigoSalon.setText(((Salones) tblSalones.getSelectionModel().getSelectedItem()).getCodigoSalones());
            txtDescripcion.setText(((Salones) tblSalones.getSelectionModel().getSelectedItem()).getDescripcion());
            txtCapacidadMaxima.setText(String.valueOf(((Salones) tblSalones.getSelectionModel().getSelectedItem()).getCapacidadMaxima()));
            txtEdificio.setText(((Salones) tblSalones.getSelectionModel().getSelectedItem()).getEdificio());
            txtNivel.setText(String.valueOf(((Salones) tblSalones.getSelectionModel().getSelectedItem()).getNivel()));
        }
    }

    public Principal getEcenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEcenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }

    // TEXTOS
    @FXML
    private TextField txtCodigoSalon;
    @FXML
    private TextField txtDescripcion;
    @FXML
    private TextField txtCapacidadMaxima;
    @FXML
    private TextField txtEdificio;
    @FXML
    private TextField txtNivel;

    // BOTONES
    @FXML
    private Button btnNuevo;
    @FXML
    private Button btnModificar;
    @FXML
    private Button btnEliminar;
    @FXML
    private Button btnReporte;

    // TABLAS 
    @FXML
    private TableView tblSalones;
    @FXML
    private TableColumn colCodigoSalon;
    @FXML
    private TableColumn colDescripcion;
    @FXML
    private TableColumn colCapacidadMaxima;
    @FXML
    private TableColumn colEdificio;
    @FXML
    private TableColumn colNivel;

    @FXML
    private ImageView imgNuevo;
    @FXML
    private ImageView imgModificar;
    @FXML
    private ImageView imgEliminar;

    @FXML

    private void habilitarCampos() {
        txtCodigoSalon.setEditable(true);
        txtDescripcion.setEditable(true);
        txtCapacidadMaxima.setEditable(true);
        txtEdificio.setEditable(true);
        txtNivel.setEditable(true);

        txtCodigoSalon.setDisable(false);
        txtDescripcion.setDisable(false);
        txtCapacidadMaxima.setDisable(false);
        txtEdificio.setDisable(false);
        txtNivel.setDisable(false);
    }

    private void limpiarCampos() {
        txtCodigoSalon.setText("");
        txtDescripcion.setText("");
        txtCapacidadMaxima.setText("");
        txtEdificio.setText("");
        txtNivel.setText("");
    }

    @FXML
    private void clicEliminar() {
        switch (operacion) {
            case ACTUALIZAR:
                btnNuevo.setDisable(false);
                btnNuevo.setVisible(true);

                btnModificar.setText("Modificar");
                imgModificar.setImage(new Image(PAQUETE_IMAGE + "editavvv .png"));

                btnEliminar.setText("Eliminar");
                imgEliminar.setImage(new Image(PAQUETE_IMAGE + "expediente.png"));

                btnReporte.setDisable(false);
                btnReporte.setVisible(true);

                limpiarCampos();
                deshabilitarCampos();

                operacion = SalonesController.Operacion.NINGUNO;
                break;

            case NINGUNO:
                if (existeElementoSeleccionado()) {

                    if (eliminarSalon()) {
                        listaSalones.remove(tblSalones.getSelectionModel().getFocusedIndex());
                    }
                }
                break;
        }
    }

    private void deshabilitarCampos() {
        txtCodigoSalon.setEditable(false);
        txtDescripcion.setEditable(false);
        txtCapacidadMaxima.setEditable(false);
        txtEdificio.setEditable(false);
        txtNivel.setEditable(false);

        txtCodigoSalon.setDisable(true);
        txtDescripcion.setDisable(true);
        txtCapacidadMaxima.setDisable(true);
        txtEdificio.setDisable(true);
        txtNivel.setDisable(true);
    }

    @FXML
    private void clicNuevo() {
       switch (operacion) {
            case NINGUNO:
                habilitarCampos();
                limpiarCampos();
                btnNuevo.setText("Guardar");
                imgNuevo.setImage(new Image(PAQUETE_IMAGE + "save_78348.png"));

                btnModificar.setText("Cancelar");
                imgModificar.setImage(new Image(PAQUETE_IMAGE + "ic_cancel_128_28318.png"));

                btnEliminar.setDisable(true);
                btnEliminar.setVisible(false);

                btnReporte.setDisable(true);
                btnReporte.setVisible(false);

                limpiarCampos();
                habilitarCampos();

                operacion = Operacion.GUARDAR;
                break;
        }
    }

    @FXML
    private void clicModificar() {
       switch (operacion) {
            case NINGUNO:
                habilitarCampos();

                btnNuevo.setDisable(true);
                btnNuevo.setVisible(false);

                btnModificar.setText("Guardar");
                imgModificar.setImage(new Image(PAQUETE_IMAGE + "save_78348.png"));

                btnEliminar.setText("Cancelar");
                imgEliminar.setImage(new Image(PAQUETE_IMAGE + "ic_cancel_128_28318.png"));

                btnReporte.setDisable(true);
                btnReporte.setVisible(false);

                operacion = SalonesController.Operacion.ACTUALIZAR;

                break;
            case GUARDAR: //cancelar una insercion
                btnNuevo.setText("Nuevo");
                imgNuevo.setImage(new Image(PAQUETE_IMAGE + "agregar-archivo.png"));

                btnModificar.setText("Modificar");
                imgModificar.setImage(new Image(PAQUETE_IMAGE + "editavvv .png"));

                btnEliminar.setDisable(false);
                btnEliminar.setVisible(true);

                btnReporte.setDisable(false);
                btnReporte.setVisible(true);

                limpiarCampos();
                deshabilitarCampos();

                operacion = SalonesController.Operacion.NINGUNO;
                break;
        }
    }

    @FXML
    public void clicRegresar() {
        escenarioPrincipal.mostrarScenaPrincipal();
    }

    @FXML
    private void clicReporte() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setTitle("AVISO");
        alert.setContentText("Esta opcion esta disponible solo para la version PRO !");

        Stage stageAlert = (Stage) alert.getDialogPane().getScene().getWindow();
        stageAlert.getIcons().add(new Image(PAQUETE_IMAGE + "K (1).png"));
        alert.showAndWait();
    }

}
