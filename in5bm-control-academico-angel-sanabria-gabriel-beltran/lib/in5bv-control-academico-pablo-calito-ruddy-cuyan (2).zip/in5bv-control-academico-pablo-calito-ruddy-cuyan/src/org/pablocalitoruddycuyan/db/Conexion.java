package org.pablocalitoruddycuyan.db;

/**
 *
 * @author Pablo Andrés Calito del Cid
 * @date 3 may 2022
 * @time 17:00:12
 *
 * Carne: 2021253 Codigo Tecnico: IN5BV Carrera: Informatica Grupo: 2 Jornada:
 * Vespertina
 */
import com.mysql.cj.jdbc.exceptions.CommunicationsException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.DatabaseMetaData;

public class Conexion {

    private final String IP_SERVER = "localhost";
    private final String PORT = "3306";
    private final String DB = "db_control_academico_in5bv";
    private final String USER = "kinal";
    private final String PASSWORD = "admin";
    private final String URL;
    private Connection conexion;

    private static Conexion instancia;

    public static Conexion getInstance() {
        if (instancia == null) {
            instancia = new Conexion();
        }
        return instancia;
    }

    private Conexion() {
        URL = "jdbc:mysql://" + IP_SERVER + ":" + PORT + "/" + DB;

        try {
            // Class.forName("com.mysql.jdbc.Driver").newInstance();
            //Class.forName("com.mysql.jdbc.Driver");
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexion Exitosa !!!");

            DatabaseMetaData dma = conexion.getMetaData();
            System.out.println("\nConnected to: " + dma.getURL());
            System.out.println("Driver: " + dma.getDriverName());
            System.out.println("Version: " + dma.getDriverVersion());
            /*
        }catch(InstantiationException ex){
            System.err.println("No se puede crear una instancia del objeto ");
        }catch(IllegalAccessException ex){
            System.err.println("No se tienen los permisos para acceder al paquete");
            ex.printStackTrace();
             */
        } catch (ClassNotFoundException ex) {
            System.err.println("No se ecuntra ninguna definicion en la clase");
            ex.printStackTrace();
        } catch (CommunicationsException ex) {
            System.err.println("No se puede establecer comunicacion con el servIdor de MySQL"
                    + "\n Recomendaciones:"
                    + "\n Verifique que el nombre de HOST o la IP_SERVER sea correcta"
                    + "\n Verifique que el numero del puerto sea correcto"
                    + "\n Verifique que el servicio de MySQL este en ejecucion o levantado");
            ex.printStackTrace();
        } catch (SQLException ex) {
            System.err.println("Seprodijo un error de tipo SQLExection");
            System.err.println("Message " + ex.getMessage());
            System.err.println("Error code " + ex.getErrorCode());
            System.err.println("SQLState " + ex.getSQLState());
            ex.printStackTrace();
        } catch (Exception ex) {
            System.err.println("Se produjo un error al intentar establecer una conexion con la base de datos");
            ex.printStackTrace();
        }
    }
   
    public Connection getConexion() {
        return conexion;
    }
    
    
}
