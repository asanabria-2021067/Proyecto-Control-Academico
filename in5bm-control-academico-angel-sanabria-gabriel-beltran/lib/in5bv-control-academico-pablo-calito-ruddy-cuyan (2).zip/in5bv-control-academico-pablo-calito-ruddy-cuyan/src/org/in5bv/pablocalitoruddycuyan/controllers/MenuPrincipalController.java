package org.in5bv.pablocalitoruddycuyan.controllers;

import java.net.URL;
import java.util.ResourceBundle;
import static javafx.application.Platform.exit;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import org.in5bv.pablocalitoruddycuyan.system.Principal;

/**
 *
 * @author informatica
 */
public class MenuPrincipalController implements Initializable {

    private Principal escenarioPrincipal;

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {

    }

    public Principal getEcenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEcenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }

    @FXML
    public void clicAlumnos() {
        escenarioPrincipal.mostrarScenaAlumnos();
    }

    @FXML
    public void clicSalones() {
        escenarioPrincipal.mostrarScenaSalones();
    }

    @FXML
    public void clicCarrerasTecnicas() {
        escenarioPrincipal.mostrarScenaCarrerasTecnicas();
    }
    
    @FXML
    public void clicSalir() {
        System.exit(0);
    }

}
